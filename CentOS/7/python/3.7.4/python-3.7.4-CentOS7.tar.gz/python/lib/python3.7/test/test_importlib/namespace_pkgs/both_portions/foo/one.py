attr = 'both_portions foo one'
